<?php $shortname = "bordergrid"; ?>

<div class="footer_copyright_cont">

<div class="footer_copyright">

	<div class="container">

	
		
		© 2015 All Rights Reserved. Developed by <a href="http://dessign.net">Dessign.net</a></div>

		<div class="clear"></div>

	</div><!--//container-->

</div><!--//footer_copyright-->

</div><!--//footer_copyright_cont-->

<?php wp_footer(); ?>

</body>

</html>